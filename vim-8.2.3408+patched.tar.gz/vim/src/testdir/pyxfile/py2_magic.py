# requires python 2.x

import sys
print(sys.version)
